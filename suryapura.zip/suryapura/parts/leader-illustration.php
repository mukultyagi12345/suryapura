<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<svg viewBox="0 0 400 440" width="100%" height="100%" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Illustration of a rural leader">
	<defs>
		<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
			<stop offset="0" stop-color="#f6a623"/><stop offset="1" stop-color="#ef7c12"/>
		</linearGradient>
		<linearGradient id="field" x1="0" y1="0" x2="0" y2="1">
			<stop offset="0" stop-color="#1c8a52"/><stop offset="1" stop-color="#0c3d24"/>
		</linearGradient>
	</defs>
	<rect width="400" height="440" fill="url(#sky)"/>
	<circle cx="300" cy="92" r="54" fill="#fff3d6" opacity=".55"/>
	<circle cx="300" cy="92" r="34" fill="#fff"/>
	<path d="M0 300 Q200 250 400 300 V440 H0 Z" fill="url(#field)"/>
	<path d="M0 330 Q200 290 400 330" stroke="#2fa769" stroke-width="3" fill="none" opacity=".5"/>
	<path d="M0 360 Q200 322 400 360" stroke="#2fa769" stroke-width="3" fill="none" opacity=".4"/>
	<g transform="translate(140,150)">
		<ellipse cx="60" cy="300" rx="120" ry="40" fill="#0c3d24" opacity=".25"/>
		<path d="M10 300 Q15 190 60 180 Q105 190 110 300 Z" fill="#f4ede0"/>
		<path d="M60 180 L60 300" stroke="#d9cdb6" stroke-width="2"/>
		<path d="M30 200 Q60 230 90 200 L78 250 Q60 262 42 250 Z" fill="#ef7c12"/>
		<rect x="48" y="150" width="24" height="40" rx="10" fill="#caa06a"/>
		<circle cx="60" cy="128" r="34" fill="#d6ac74"/>
		<path d="M26 120 Q60 78 94 120 Q96 96 60 92 Q24 96 26 120 Z" fill="#1c8a52"/>
		<path d="M26 120 Q60 100 94 120" stroke="#c9a227" stroke-width="4" fill="none"/>
		<circle cx="84" cy="104" r="5" fill="#c9a227"/>
		<path d="M48 132 q4 5 0 9 M72 132 q-4 5 0 9" stroke="#5b4326" stroke-width="2.5" fill="none" stroke-linecap="round"/>
		<path d="M50 150 q10 7 20 0" stroke="#5b4326" stroke-width="2.5" fill="none" stroke-linecap="round"/>
	</g>
</svg>
