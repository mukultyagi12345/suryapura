<?php
/**
 * Front page — Suryapura Village Development Portal
 * All content is read from the ACF options page ("Portal Settings").
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

$leader_name  = sp_opt( 'leader_name', 'Vikram Singh Rathore' );
$leader_role  = sp_opt( 'leader_role', 'Development Ambassador · Suryapura Panchayat' );
$leader_photo = sp_opt( 'leader_photo', '' );
?>

<!-- ===== HERO BANNER ===== -->
<section class="hero">
	<div class="wrap hero-grid">
		<div class="hero-copy">
			<span class="eyebrow light"><?php echo esc_html( sp_opt( 'hero_eyebrow', '🌾 Every Village · Every Dream · Every Opportunity' ) ); ?></span>
			<h1><?php echo esc_html( sp_opt( 'hero_heading', 'Village Development,' ) ); ?><br><span class="hl"><?php echo esc_html( sp_opt( 'hero_highlight', 'now in every hand' ) ); ?></span></h1>
			<p class="lead"><?php echo esc_html( sp_opt( 'hero_lead', 'From education to the fields, from roads to digital identity — every family in Suryapura is now part of the mainstream of development. One portal, the progress of the whole village.' ) ); ?></p>
			<div class="cta-row">
				<a href="<?php echo esc_attr( sp_opt( 'hero_btn1_link', '#join' ) ); ?>" class="btn btn-primary"><?php echo esc_html( sp_opt( 'hero_btn1', 'Join the Movement' ) ); ?></a>
				<a href="#leader" class="btn btn-ghost">▶ <?php echo esc_html( sp_opt( 'hero_btn2', 'The Leadership Story' ) ); ?></a>
			</div>
			<div class="stat-row">
				<?php if ( have_rows( 'hero_stats', 'option' ) ) : ?>
					<?php while ( have_rows( 'hero_stats', 'option' ) ) : the_row(); ?>
						<div class="stat"><div class="n num"><?php echo esc_html( get_sub_field( 'num' ) ); ?></div><div class="l"><?php echo esc_html( get_sub_field( 'label' ) ); ?></div></div>
					<?php endwhile; ?>
				<?php else :
					foreach ( array(
						array( 'num' => '128',  'label' => 'Villages Connected' ),
						array( 'num' => '42k+', 'label' => 'Digital IDs' ),
						array( 'num' => '96%',  'label' => 'Panchayat Participation' ),
					) as $s ) : ?>
						<div class="stat"><div class="n num"><?php echo esc_html( $s['num'] ); ?></div><div class="l"><?php echo esc_html( $s['label'] ); ?></div></div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>

		<!-- Hero portrait -->
		<div class="portrait-card">
			<?php if ( $leader_photo ) : ?>
				<img src="<?php echo esc_url( $leader_photo ); ?>" alt="<?php echo esc_attr( $leader_name ); ?>" style="width:100%;height:100%;object-fit:cover;">
			<?php else : ?>
				<?php get_template_part( 'parts/leader', 'illustration' ); ?>
			<?php endif; ?>
			<div class="badge">
				<span class="dot"><?php echo esc_html( mb_substr( $leader_name, 0, 1 ) ); ?></span>
				<div>
					<b><?php echo esc_html( $leader_name ); ?></b>
					<span><?php echo esc_html( $leader_role ); ?></span>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ===== FOCUS / PILLARS ===== -->
<section class="section" id="focus">
	<div class="wrap">
		<div class="sec-head">
			<span class="eyebrow"><?php echo esc_html( sp_opt( 'pillars_eyebrow', 'Pillars of Development' ) ); ?></span>
			<h2><?php echo esc_html( sp_opt( 'pillars_heading', 'Six Directions, One Resolve' ) ); ?></h2>
			<p><?php echo esc_html( sp_opt( 'pillars_sub', 'The services that reach every family and make a village self-reliant.' ) ); ?></p>
		</div>
		<div class="cards">
			<?php if ( have_rows( 'pillars', 'option' ) ) : ?>
				<?php while ( have_rows( 'pillars', 'option' ) ) : the_row(); ?>
					<article class="card <?php echo esc_attr( suryapura_card_class( get_sub_field( 'color' ) ) ); ?>">
						<div class="ico"><?php echo suryapura_icon( get_sub_field( 'icon' ) ); ?></div>
						<h3><?php echo esc_html( get_sub_field( 'title' ) ); ?></h3>
						<p><?php echo esc_html( get_sub_field( 'text' ) ); ?></p>
					</article>
				<?php endwhile; ?>
			<?php else :
				foreach ( array(
					array( 'icon' => 'education', 'color' => 'green',   'title' => 'Education',              'text' => 'Smart classes, a digital library and scholarships — equal opportunity to learn for every child.' ),
					array( 'icon' => 'farmer',    'color' => 'saffron', 'title' => 'Farmers',                'text' => 'Mandi prices, weather alerts, seed & fertiliser subsidy and direct market access — farming that finally pays.' ),
					array( 'icon' => 'road',      'color' => 'gold',    'title' => 'Roads & Infrastructure', 'text' => 'Paved roads to every farm and home, street lights and real-time progress on drainage.' ),
					array( 'icon' => 'panchayat', 'color' => 'green',   'title' => 'Panchayat',              'text' => 'Transparent budgets, online grievances and live Gram Sabha proceedings — decisions in the open.' ),
					array( 'icon' => 'digital',   'color' => 'saffron', 'title' => 'Digital Identity',        'text' => 'One QR village-ID for every service — ration, pension and certificates, now a tap away.' ),
					array( 'icon' => 'health',    'color' => 'gold',    'title' => 'Health',                 'text' => 'Tele-medicine, vaccination reminders and mother-&-child care — health is the village priority.' ),
				) as $p ) : ?>
					<article class="card <?php echo esc_attr( suryapura_card_class( $p['color'] ) ); ?>">
						<div class="ico"><?php echo suryapura_icon( $p['icon'] ); ?></div>
						<h3><?php echo esc_html( $p['title'] ); ?></h3>
						<p><?php echo esc_html( $p['text'] ); ?></p>
					</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>

<!-- ===== DIGITAL IDENTITY ===== -->
<section class="section alt" id="identity">
	<div class="wrap split">
		<div class="panel">
			<span class="eyebrow light"><?php echo esc_html( sp_opt( 'id_eyebrow', 'Digital Suryapura' ) ); ?></span>
			<h2 style="font-size:34px;margin-top:14px;"><?php echo esc_html( sp_opt( 'id_heading', 'One Identity, Full Transparency' ) ); ?></h2>
			<p style="color:rgba(255,255,255,.85);margin-top:12px;"><?php echo esc_html( sp_opt( 'id_text', 'A digital village-ID for every resident, connecting them directly to government schemes — no middlemen, no delays.' ) ); ?></p>
			<ul class="check-list">
				<?php if ( have_rows( 'id_points', 'option' ) ) : ?>
					<?php while ( have_rows( 'id_points', 'option' ) ) : the_row(); ?>
						<li><span class="tick">✓</span> <?php echo esc_html( get_sub_field( 'point' ) ); ?></li>
					<?php endwhile; ?>
				<?php else :
					foreach ( array(
						'Instant service verification via QR code',
						'Scheme benefits straight to the bank account (DBT)',
						'Certificates & ration — paperless',
						'Live complaint status on your mobile',
					) as $pt ) : ?>
						<li><span class="tick">✓</span> <?php echo esc_html( $pt ); ?></li>
					<?php endforeach; ?>
				<?php endif; ?>
			</ul>
		</div>
		<div class="id-card">
			<div style="display:flex;justify-content:space-between;align-items:center;">
				<div>
					<div style="font-size:12px;letter-spacing:.14em;color:var(--muted);text-transform:uppercase;font-weight:700;">Village Digital Identity</div>
					<div class="serif" style="font-size:22px;margin-top:4px;"><?php echo esc_html( sp_opt( 'idc_name', 'Sunita Devi' ) ); ?></div>
				</div>
				<div style="width:62px;height:62px;border-radius:12px;background:repeating-linear-gradient(45deg,#0c3d24 0 6px,#fff 6px 12px);"></div>
			</div>
			<div style="margin-top:14px;">
				<div class="row"><span class="k">Village ID</span><span class="v num"><?php echo esc_html( sp_opt( 'idc_number', 'SP-2026-04417' ) ); ?></span></div>
				<div class="row"><span class="k">Panchayat</span><span class="v"><?php echo esc_html( sp_opt( 'idc_panchayat', 'Suryapura' ) ); ?></span></div>
				<div class="row"><span class="k">Active Schemes</span><span class="v num"><?php echo esc_html( sp_opt( 'idc_schemes', '5' ) ); ?></span></div>
				<div class="row"><span class="k">Status</span><span class="v" style="color:var(--green-500);">● Verified</span></div>
			</div>
		</div>
	</div>
</section>

<!-- ===== LEADER QUOTE ===== -->
<section class="section" id="leader">
	<div class="wrap quote">
		<span class="eyebrow">Development Ambassador</span>
		<blockquote style="margin-top:18px;">“<?php echo esc_html( sp_opt( 'leader_quote', 'I dreamed of changing the very village whose soil raised me. Development comes true only when the lamp of the last house is lit too.' ) ); ?>”</blockquote>
		<cite>— <?php echo esc_html( $leader_name . ', ' . $leader_role ); ?></cite>
	</div>
</section>

<!-- ===== CTA ===== -->
<section class="section alt" id="join">
	<div class="wrap">
		<div class="cta-band">
			<h2><?php echo esc_html( sp_opt( 'cta_heading', 'Bring Your Village Onboard' ) ); ?></h2>
			<p><?php echo esc_html( sp_opt( 'cta_text', 'The Suryapura model, now in your village. Register today and be part of this wave of development.' ) ); ?></p>
			<a href="#" class="btn btn-dark" style="background:#fff;color:var(--saffron);"><?php echo esc_html( sp_opt( 'cta_btn', 'Register for Free →' ) ); ?></a>
		</div>
	</div>
</section>

<?php get_footer(); ?>
