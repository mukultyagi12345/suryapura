<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<footer id="voice">
	<div class="wrap">
		<div class="foot-grid">
			<div>
				<h4><?php bloginfo( 'name' ); ?></h4>
				<p style="font-size:15px;max-width:340px;">
					<?php echo esc_html( sp_opt( 'foot_about', 'Every village, every dream, every opportunity. Building a new story for rural India — with technology and empathy.' ) ); ?>
				</p>
			</div>
			<div>
				<h4>Quick Links</h4>
				<a href="#focus">Pillars of Development</a>
				<a href="#identity">Digital Identity</a>
				<a href="#join">Register</a>
			</div>
			<div>
				<h4>GramVoice</h4>
				<a href="#">File a Complaint</a>
				<a href="#"><?php echo esc_html( sp_opt( 'foot_helpline', 'Helpline: 1800-XXX' ) ); ?></a>
				<a href="#">Contact Us</a>
			</div>
		</div>
		<div class="foot-bottom">
			<span>© <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — A Fictional Demo</span>
			<span>Proudly built for rural India 🌾</span>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
