<?php
/**
 * Fallback template (blog / archive / single).
 * The homepage uses front-page.php.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<section class="section">
	<div class="wrap">
		<?php if ( have_posts() ) : ?>
			<div class="sec-head">
				<span class="eyebrow">GramVoice</span>
				<h2><?php echo is_home() ? 'News &amp; Updates' : esc_html( get_the_archive_title() ); ?></h2>
			</div>
			<div class="cards">
				<?php while ( have_posts() ) : the_post(); ?>
					<article class="card c-green">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 26 ) ); ?></p>
					</article>
				<?php endwhile; ?>
			</div>
			<div style="margin-top:30px;text-align:center;"><?php the_posts_pagination(); ?></div>
		<?php else : ?>
			<div class="sec-head"><h2>No content yet</h2><p>New information will be added soon.</p></div>
		<?php endif; ?>
	</div>
</section>

<?php get_footer(); ?>
