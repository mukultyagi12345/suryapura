<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
	<div class="wrap nav">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<span class="logo" aria-hidden="true">
				<svg viewBox="0 0 24 24" fill="none"><path d="M12 2l2.6 5.6L21 8.4l-4.5 4.3 1.1 6.3L12 16.9 6.4 19l1.1-6.3L3 8.4l6.4-.8L12 2z" fill="currentColor"/></svg>
			</span>
			<div>
				<b><?php bloginfo( 'name' ); ?></b>
				<small><?php echo esc_html( get_bloginfo( 'description' ) ?: 'Village Development Portal' ); ?></small>
			</div>
		</a>

		<nav class="nav-links">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1 ) );
			} else {
				echo '<a href="#focus">Development</a><a href="#identity">Digital Identity</a><a href="#leader">Leadership</a><a href="#voice">GramVoice</a>';
			}
			?>
		</nav>

		<a href="#join" class="btn btn-dark show-desk">Join Now →</a>
		<button class="menu-toggle" aria-label="Menu" onclick="document.querySelector('.nav-links').classList.toggle('open')">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
		</button>
	</div>
</header>
