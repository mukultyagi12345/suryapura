<?php
/**
 * सूर्यपुरा ग्राम विकास पोर्टल — theme bootstrap
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SURYAPURA_VER', '1.0.0' );

/* -------------------------------------------------
 * Theme supports
 * ------------------------------------------------- */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'navigation-widgets', 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo' );
	register_nav_menus( array(
		'primary' => __( 'मुख्य मेन्यू', 'suryapura' ),
	) );
} );

/* -------------------------------------------------
 * Assets
 * ------------------------------------------------- */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'suryapura-fonts',
		'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Poppins:wght@500;600;700&display=swap',
		array(), null
	);
	wp_enqueue_style(
		'suryapura-main',
		get_template_directory_uri() . '/assets/css/main.css',
		array( 'suryapura-fonts' ),
		SURYAPURA_VER
	);
} );

/* -------------------------------------------------
 * ACF — field groups + options page (registered in code)
 * ------------------------------------------------- */
require_once get_template_directory() . '/inc/acf-fields.php';

/* Graceful note if ACF is missing */
add_action( 'admin_notices', function () {
	if ( ! class_exists( 'ACF' ) ) {
		echo '<div class="notice notice-error"><p><strong>सूर्यपुरा थीम:</strong> कृपया Advanced Custom Fields (Pro) प्लगइन सक्रिय करें — सारी होमपेज सामग्री ACF से नियंत्रित होती है।</p></div>';
	}
} );

/* -------------------------------------------------
 * Helpers — icon library used by the "विकास स्तंभ" cards
 * ------------------------------------------------- */
function suryapura_icon( $key ) {
	$icons = array(
		'education' => '<path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1 2.7 2 6 2s6-1 6-2v-5"/>',
		'farmer'    => '<path d="M12 2C8 6 7 10 12 22 17 10 16 6 12 2z"/>',
		'road'      => '<path d="M4 19h16M6 19V9l6-5 6 5v10"/>',
		'panchayat' => '<path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/>',
		'digital'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M13 9h5M13 13h5M5 16h14"/>',
		'health'    => '<path d="M12 21s-7-4.5-9-9a5 5 0 019-3 5 5 0 019 3c-2 4.5-9 9-9 9z"/>',
	);
	$path = isset( $icons[ $key ] ) ? $icons[ $key ] : $icons['panchayat'];
	return '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' . $path . '</svg>';
}

/* Map a colour choice to the card modifier class */
function suryapura_card_class( $color ) {
	$map = array( 'green' => 'c-green', 'saffron' => 'c-saff', 'gold' => 'c-gold' );
	return isset( $map[ $color ] ) ? $map[ $color ] : 'c-green';
}

/* Tiny ACF-with-fallback reader for options fields */
function sp_opt( $name, $fallback = '' ) {
	if ( function_exists( 'get_field' ) ) {
		$v = get_field( $name, 'option' );
		if ( $v !== null && $v !== '' && $v !== false ) return $v;
	}
	return $fallback;
}
