<?php
/**
 * ACF — Options page registration only.
 *
 * The "Homepage Content" field group is now stored in the DATABASE and is
 * fully editable from the ACF admin UI (Custom Fields → Field Groups).
 * It is no longer registered in code, so you can add/edit/reorder fields
 * normally inside the ACF plugin.
 *
 * NOTE: In ACF Pro 5.12 an options page must still be registered in code
 * (the UI option-page builder only exists in ACF 6.2+). This is the
 * standard, documented way to add an options page.
 *
 * To (re)create the field group in the DB from code, run once:
 *   wp eval-file wp-content/themes/suryapura/inc/import-fields.php
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_options_page' ) ) return;

	acf_add_options_page( array(
		'page_title' => 'Suryapura Portal Settings',
		'menu_title' => 'Portal Settings',
		'menu_slug'  => 'suryapura-settings',
		'capability' => 'edit_posts',
		'icon_url'   => 'dashicons-bank',
		'position'   => 2,
		'redirect'   => false,
	) );
} );
