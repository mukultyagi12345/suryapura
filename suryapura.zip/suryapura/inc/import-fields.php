<?php
/**
 * One-time: import the "Homepage Content" field group into the DATABASE
 * so it becomes fully editable inside the ACF admin UI
 * (Custom Fields → Field Groups), instead of being locked as PHP code.
 *
 * Run once:  wp eval-file wp-content/themes/suryapura/inc/import-fields.php
 *
 * Keys are identical to the previous local group, so existing option
 * values (seeded earlier) stay correctly mapped.
 */
if ( ! function_exists( 'acf_import_field_group' ) ) {
	WP_CLI::error( 'ACF Pro not active.' );
	return;
}

$icon_choices  = array(
	'education' => 'Education',
	'farmer'    => 'Farmers',
	'road'      => 'Roads / Infrastructure',
	'panchayat' => 'Panchayat',
	'digital'   => 'Digital Identity',
	'health'    => 'Health',
);
$color_choices = array( 'green' => 'Green', 'saffron' => 'Saffron', 'gold' => 'Gold' );

$group = array(
	'key'    => 'group_suryapura_home',
	'title'  => 'Homepage Content',
	'fields' => array(

		array( 'key' => 'tab_hero', 'label' => 'Hero Banner', 'type' => 'tab' ),
		array( 'key' => 'f_hero_eyebrow', 'label' => 'Eyebrow (top strip)', 'name' => 'hero_eyebrow', 'type' => 'text' ),
		array( 'key' => 'f_hero_heading', 'label' => 'Main Heading', 'name' => 'hero_heading', 'type' => 'text' ),
		array( 'key' => 'f_hero_highlight', 'label' => 'Heading Highlight', 'name' => 'hero_highlight', 'type' => 'text' ),
		array( 'key' => 'f_hero_lead', 'label' => 'Sub-text', 'name' => 'hero_lead', 'type' => 'textarea', 'rows' => 3 ),
		array( 'key' => 'f_hero_btn1', 'label' => 'Primary Button Text', 'name' => 'hero_btn1', 'type' => 'text' ),
		array( 'key' => 'f_hero_btn1_link', 'label' => 'Primary Button Link', 'name' => 'hero_btn1_link', 'type' => 'text', 'default_value' => '#join' ),
		array( 'key' => 'f_hero_btn2', 'label' => 'Secondary Button Text', 'name' => 'hero_btn2', 'type' => 'text' ),
		array(
			'key' => 'f_hero_stats', 'label' => 'Stats', 'name' => 'hero_stats', 'type' => 'repeater',
			'button_label' => 'Add Stat', 'layout' => 'table',
			'sub_fields' => array(
				array( 'key' => 'f_stat_num', 'label' => 'Number', 'name' => 'num', 'type' => 'text' ),
				array( 'key' => 'f_stat_lbl', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ),
			),
		),

		array( 'key' => 'tab_leader', 'label' => 'Development Ambassador', 'type' => 'tab' ),
		array( 'key' => 'f_leader_name', 'label' => 'Leader Name', 'name' => 'leader_name', 'type' => 'text' ),
		array( 'key' => 'f_leader_role', 'label' => 'Role / Title', 'name' => 'leader_role', 'type' => 'text' ),
		array( 'key' => 'f_leader_photo', 'label' => 'Photo (optional — an illustration is drawn automatically if empty)', 'name' => 'leader_photo', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' ),
		array( 'key' => 'f_leader_quote', 'label' => 'Emotional Quote', 'name' => 'leader_quote', 'type' => 'textarea', 'rows' => 3 ),

		array( 'key' => 'tab_pillars', 'label' => 'Pillars of Development', 'type' => 'tab' ),
		array( 'key' => 'f_pil_eyebrow', 'label' => 'Eyebrow', 'name' => 'pillars_eyebrow', 'type' => 'text' ),
		array( 'key' => 'f_pil_heading', 'label' => 'Heading', 'name' => 'pillars_heading', 'type' => 'text' ),
		array( 'key' => 'f_pil_sub', 'label' => 'Sub-text', 'name' => 'pillars_sub', 'type' => 'text' ),
		array(
			'key' => 'f_pillars', 'label' => 'Pillar Cards', 'name' => 'pillars', 'type' => 'repeater',
			'button_label' => 'Add Pillar', 'layout' => 'block',
			'sub_fields' => array(
				array( 'key' => 'f_pil_icon', 'label' => 'Icon', 'name' => 'icon', 'type' => 'select', 'choices' => $icon_choices ),
				array( 'key' => 'f_pil_color', 'label' => 'Color', 'name' => 'color', 'type' => 'select', 'choices' => $color_choices ),
				array( 'key' => 'f_pil_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
				array( 'key' => 'f_pil_text', 'label' => 'Description', 'name' => 'text', 'type' => 'textarea', 'rows' => 2 ),
			),
		),

		array( 'key' => 'tab_id', 'label' => 'Digital Identity', 'type' => 'tab' ),
		array( 'key' => 'f_id_eyebrow', 'label' => 'Eyebrow', 'name' => 'id_eyebrow', 'type' => 'text' ),
		array( 'key' => 'f_id_heading', 'label' => 'Heading', 'name' => 'id_heading', 'type' => 'text' ),
		array( 'key' => 'f_id_text', 'label' => 'Description', 'name' => 'id_text', 'type' => 'textarea', 'rows' => 2 ),
		array(
			'key' => 'f_id_points', 'label' => 'Checklist Points', 'name' => 'id_points', 'type' => 'repeater',
			'button_label' => 'Add Point', 'layout' => 'table',
			'sub_fields' => array(
				array( 'key' => 'f_id_point', 'label' => 'Point', 'name' => 'point', 'type' => 'text' ),
			),
		),
		array( 'key' => 'f_idc_name', 'label' => 'Card: Name', 'name' => 'idc_name', 'type' => 'text' ),
		array( 'key' => 'f_idc_number', 'label' => 'Card: Village ID', 'name' => 'idc_number', 'type' => 'text' ),
		array( 'key' => 'f_idc_panchayat', 'label' => 'Card: Panchayat', 'name' => 'idc_panchayat', 'type' => 'text' ),
		array( 'key' => 'f_idc_schemes', 'label' => 'Card: Active Schemes', 'name' => 'idc_schemes', 'type' => 'text' ),

		array( 'key' => 'tab_cta', 'label' => 'CTA & Footer', 'type' => 'tab' ),
		array( 'key' => 'f_cta_heading', 'label' => 'CTA Heading', 'name' => 'cta_heading', 'type' => 'text' ),
		array( 'key' => 'f_cta_text', 'label' => 'CTA Description', 'name' => 'cta_text', 'type' => 'textarea', 'rows' => 2 ),
		array( 'key' => 'f_cta_btn', 'label' => 'CTA Button', 'name' => 'cta_btn', 'type' => 'text' ),
		array( 'key' => 'f_foot_about', 'label' => 'Footer: About', 'name' => 'foot_about', 'type' => 'textarea', 'rows' => 2 ),
		array( 'key' => 'f_foot_helpline', 'label' => 'Footer: Helpline', 'name' => 'foot_helpline', 'type' => 'text' ),
	),
	'location' => array(
		array(
			array( 'param' => 'options_page', 'operator' => '==', 'value' => 'suryapura-settings' ),
		),
	),
	'menu_order' => 0,
	'position'   => 'normal',
	'style'      => 'default',
	'active'     => true,
);

/* If an old DB copy exists, remove it first so we don't duplicate. */
if ( $existing = acf_get_field_group( 'group_suryapura_home' ) ) {
	if ( ! empty( $existing['ID'] ) ) {
		acf_delete_field_group( $existing['ID'] );
	}
}

$result = acf_import_field_group( $group );

if ( ! empty( $result['ID'] ) ) {
	WP_CLI::success( 'Field group imported into DB (editable in ACF admin). ID: ' . $result['ID'] );
} else {
	WP_CLI::error( 'Import failed.' );
}
