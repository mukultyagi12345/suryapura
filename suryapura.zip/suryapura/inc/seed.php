<?php
/**
 * One-time seed: populate the ACF options page with demo content.
 * Run via:  wp eval-file wp-content/themes/suryapura/inc/seed.php
 */
if ( ! function_exists( 'update_field' ) ) {
	WP_CLI::error( 'ACF not active.' );
	return;
}

$o = 'option';

update_field( 'hero_eyebrow', '🌾 Every Village · Every Dream · Every Opportunity', $o );
update_field( 'hero_heading', 'Village Development,', $o );
update_field( 'hero_highlight', 'now in every hand', $o );
update_field( 'hero_lead', 'From education to the fields, from roads to digital identity — every family in Suryapura is now part of the mainstream of development. One portal, the progress of the whole village.', $o );
update_field( 'hero_btn1', 'Join the Movement', $o );
update_field( 'hero_btn1_link', '#join', $o );
update_field( 'hero_btn2', 'The Leadership Story', $o );
update_field( 'hero_stats', array(
	array( 'num' => '128',  'label' => 'Villages Connected' ),
	array( 'num' => '42k+', 'label' => 'Digital IDs' ),
	array( 'num' => '96%',  'label' => 'Panchayat Participation' ),
), $o );

update_field( 'leader_name', 'Vikram Singh Rathore', $o );
update_field( 'leader_role', 'Development Ambassador · Suryapura Panchayat', $o );
update_field( 'leader_quote', 'I dreamed of changing the very village whose soil raised me. Development comes true only when the lamp of the last house is lit too.', $o );

update_field( 'pillars_eyebrow', 'Pillars of Development', $o );
update_field( 'pillars_heading', 'Six Directions, One Resolve', $o );
update_field( 'pillars_sub', 'The services that reach every family and make a village self-reliant.', $o );
update_field( 'pillars', array(
	array( 'icon' => 'education', 'color' => 'green',   'title' => 'Education',              'text' => 'Smart classes, a digital library and scholarships — equal opportunity to learn for every child.' ),
	array( 'icon' => 'farmer',    'color' => 'saffron', 'title' => 'Farmers',                'text' => 'Mandi prices, weather alerts, seed & fertiliser subsidy and direct market access — farming that finally pays.' ),
	array( 'icon' => 'road',      'color' => 'gold',    'title' => 'Roads & Infrastructure', 'text' => 'Paved roads to every farm and home, street lights and real-time progress on drainage.' ),
	array( 'icon' => 'panchayat', 'color' => 'green',   'title' => 'Panchayat',              'text' => 'Transparent budgets, online grievances and live Gram Sabha proceedings — decisions in the open.' ),
	array( 'icon' => 'digital',   'color' => 'saffron', 'title' => 'Digital Identity',       'text' => 'One QR village-ID for every service — ration, pension and certificates, now a tap away.' ),
	array( 'icon' => 'health',    'color' => 'gold',    'title' => 'Health',                 'text' => 'Tele-medicine, vaccination reminders and mother-&-child care — health is the village priority.' ),
), $o );

update_field( 'id_eyebrow', 'Digital Suryapura', $o );
update_field( 'id_heading', 'One Identity, Full Transparency', $o );
update_field( 'id_text', 'A digital village-ID for every resident, connecting them directly to government schemes — no middlemen, no delays.', $o );
update_field( 'id_points', array(
	array( 'point' => 'Instant service verification via QR code' ),
	array( 'point' => 'Scheme benefits straight to the bank account (DBT)' ),
	array( 'point' => 'Certificates & ration — paperless' ),
	array( 'point' => 'Live complaint status on your mobile' ),
), $o );
update_field( 'idc_name', 'Sunita Devi', $o );
update_field( 'idc_number', 'SP-2026-04417', $o );
update_field( 'idc_panchayat', 'Suryapura', $o );
update_field( 'idc_schemes', '5', $o );

update_field( 'cta_heading', 'Bring Your Village Onboard', $o );
update_field( 'cta_text', 'The Suryapura model, now in your village. Register today and be part of this wave of development.', $o );
update_field( 'cta_btn', 'Register for Free →', $o );

update_field( 'foot_about', 'Every village, every dream, every opportunity. Building a new story for rural India — with technology and empathy.', $o );
update_field( 'foot_helpline', 'Helpline: 1800-XXX', $o );

WP_CLI::success( 'Suryapura content seeded (English).' );
